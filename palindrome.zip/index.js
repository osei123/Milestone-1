function palindrome(str) {
    let reg = /[\W_]/g;

    let smallStr = str.toLowerCase().replace(reg, "");

    console.log(smallStr)

    let reversed = smallStr.split("").reverse().join("");
    if (reversed === smallStr) {
        return true;
    }
    else {
        return false
    }
}

palindrome("madam")